clear;clc;close all
modulators = {'2orSC','2orGM','3orSC','211Cascade'};
model_names = {'SingleClassGB','LUTGB'};
num_iterations = [1,10];
n_mod = 4;
n_model = 2;
modulators_names = {'2nd-or SC','2nd-or GM','3rd-or SC 2-1 Cascade','4th-or SC 2-1-1 Cascade'};
f=1;
for i =1:n_mod
    for iter = 10
        figure (f)
        hold on
        for j=1:n_model
        
        
        c=Stats_calculator(modulators{i},model_names{j},iter);
        
     
        end
        f = f+1;
        ft=14;
        tt=16;
        h = ylim;
        plot([0.05,0.05],[0,h(2)],'k--')
        xlabel('E','FontSize',ft)
        ylabel('Number of occurrences','FontSize',ft)
%         title(['RNN vs LUT: ', modulators_names{i} ],'FontSize',tt)
        legend('GB+RNN','GB+LUT')
        hold off
    end
end

function c=Stats_calculator(modulator_name,model_name,num_iterations)

data_path = [cd,'\VAL-DS\sim_',modulator_name,'_',model_name,'_10.mat'];

load(data_path)

fom_sim = fom_sim(:,1:num_iterations);


SNR_sim = SNR_sim(:,1:num_iterations);
power_sim = power_sim(:,1:num_iterations);


[fom_sim,J] = max(fom_sim,[],2);



aux = fom_sim;
auy = aux;
 i = 1;
for j =1:length(J)

    aux(i,1) = SNR_sim(i,J(j));
    auy(i,1) = power_sim(i,J(j));
    i = i+1;
end
SNR_sim = aux; clear aux
power_sim = auy; clear auy


err_fom = (fom_sim-fom_asked)./fom_asked;
err_SNR = (SNR_sim-SNR_asked)./SNR_asked;
err_power = (power_sim-power_asked)./power_asked;

histogram(err_fom,'BinWidth',0.01)

T = zeros(8,3);

T(:,1) = Stats(err_fom);
T(:,2) = Stats(err_SNR);
T(:,3) = Stats(err_power);
c = T(1,3);
T = array2table(T,'VariableNames',{'FOM','SNR','Power'},'RowName',{'Mean','P(E>0)','P(E>0.05)','p(0.05)',...
    'p(0.25)','p(0.50)','p(0.75)','p(0.95)'});


printbar
fprintf([modulator_name, ', ' , model_name, ', num_iterations = ',num2str(num_iterations),'\n'])
printbar
disp(T)

end

function c = Stats(err)

m = mean(err);

P = mean(err>-.0);


alpha = [0.05,0.25,0.50,0.75,0.95];

c = zeros(3+length(alpha),1);

c(1) = m;
c(2) = P;
c(3) = mean(err>0.05);
for i = 1:length(alpha)
c(i+3) = quantile(err,alpha(i));
end

end

function printbar
fprintf('---------------------------------\n')
end